# Extension

This directory will contain the Chrome extension for Rolodex. 